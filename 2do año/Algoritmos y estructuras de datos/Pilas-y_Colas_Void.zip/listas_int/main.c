#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{

    ///COLAS - PILAS
    ///COLA: 2 --- 3 ---- 8 ---- 11 (INSERTAR FINAL)
    /// <- 2 COLA: 3----8----11 (ELIMINAR EL PRIMERO)
    ///NO PODEMOS RECORRER LA COLA FOR - WHILE


    ///PILAS--
    ///PILA: 2---3---4----5----6-----3----1 (INSERTAR FINAL)
    ///<- 1... PILA  2---3---4----5----6-----3(ELIMINAR FINAL)



    return 0;
}
